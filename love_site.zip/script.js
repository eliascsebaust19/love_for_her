function showNote() {
  document.getElementById("noteBox").style.display = "block";
}

let score = 0;
function createHeart() {
  const heart = document.createElement('div');
  heart.classList.add('heart');
  heart.textContent = '❤️';
  heart.style.left = Math.random() * 90 + '%';
  document.getElementById('gameArea').appendChild(heart);
  heart.onclick = () => {
    score++;
    document.getElementById('score').innerText = 'Score: ' + score;
    heart.remove();
  };
  setTimeout(() => heart.remove(), 5000);
}
setInterval(createHeart, 1000);

const targetDate = new Date("2026-01-27T00:00:00").getTime();
const countdownElement = document.getElementById("countdownTimer");

setInterval(() => {
  const now = new Date().getTime();
  const distance = targetDate - now;

  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);

  if (distance > 0) {
    countdownElement.innerText = `${days}d ${hours}h ${minutes}m ${seconds}s until 27 January – Our Day 💞`;
  } else {
    alert("🎉 It's 27 January, our forever day! I love you, Sarmin!");
    countdownElement.innerText = "💖 Happy 27 January, my love! Today is ours forever. 💖";
  }
}, 1000);